import tkinter as tk

from core.chat_engine import ChatEngine
from ui.chat_window import ChatWindow

if __name__ == "__main__":
    root = tk.Tk()
    motor = ChatEngine()
    app = ChatWindow(root, motor)
    root.mainloop()