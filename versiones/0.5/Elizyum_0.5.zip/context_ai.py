# ============================================================
# ELIZYUM - CONTEXT AI v3.1
# ===========================================================

# ============================================================
# ESTADOS RELACIONALES
# ============================================================

ESTADO_NORMAL = "normal"
ESTADO_DISCUSSION = "discusion"
ESTADO_DISTANTE = "distante"
ESTADO_RECONCILIACION = "reconciliacion"


# ============================================================
# UTILIDADES
# ============================================================

def limitar(valor, minimo=0, maximo=100):

    try:
        valor = int(valor)
    except (TypeError, ValueError):
        valor = 0

    return max(minimo, min(maximo, valor))


def contiene_alguna(texto, palabras):

    return any(
        palabra in texto
        for palabra in palabras
    )


def normalizar_texto(texto):

    if not isinstance(texto, str):
        return ""

    return texto.lower().strip()


# ============================================================
# DETECTAR TONO
# ============================================================

def detectar_tono(texto):

    texto = normalizar_texto(texto)

    if not texto:
        return "neutral"

    # --------------------------------------------------------
    # RECONCILIACIÓN
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "perdón",
            "perdon",
            "lo siento",
            "disculpa",
            "disculpame",
            "discúlpame",
            "no quería",
            "no queria",
            "hagamos las paces"
        ]
    ):
        return "reconciliador"

    # --------------------------------------------------------
    # ENOJO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "idiota",
            "estupida",
            "estúpida",
            "mierda",
            "carajo",
            "joder",
            "cállate",
            "callate",
            "molesto",
            "molesta",
            "enojado",
            "enojada",
            "cabreado",
            "cabreada"
        ]
    ):
        return "hostil"

    # --------------------------------------------------------
    # TRISTEZA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "estoy triste",
            "me siento triste",
            "estoy mal",
            "me siento mal",
            "estoy solo",
            "estoy sola",
            "me siento vacío",
            "me siento vacio",
            "quiero llorar",
            "estoy llorando",
            "me duele"
        ]
    ):
        return "triste"

    # --------------------------------------------------------
    # AFECTO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "te quiero",
            "te amo",
            "amor",
            "cariño",
            "linda",
            "bonita",
            "preciosa",
            "guapa"
        ]
    ):
        return "afectuoso"

    # --------------------------------------------------------
    # JUEGO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "jaja",
            "jajaja",
            "xd",
            "😂",
            "🤣",
            "broma",
            "bromeo",
            "jugar"
        ]
    ):
        return "jugueton"

    return "neutral"


# ============================================================
# DETECTAR INTENCIÓN
# ============================================================

def detectar_intencion(texto):

    texto = normalizar_texto(texto)

    if not texto:
        return "ninguna"

    # RECONCILIACIÓN

    if contiene_alguna(
        texto,
        [
            "perdón",
            "perdon",
            "lo siento",
            "disculpa",
            "disculpame",
            "discúlpame",
            "hagamos las paces"
        ]
    ):
        return "reconciliacion"

    # APOYO

    if contiene_alguna(
        texto,
        [
            "necesito ayuda",
            "ayudame",
            "ayúdame",
            "necesito hablar",
            "me siento mal",
            "estoy triste"
        ]
    ):
        return "buscar_apoyo"

    # AFECTO

    if contiene_alguna(
        texto,
        [
            "te quiero",
            "te amo",
            "te extraño",
            "te extrano",
            "me importas"
        ]
    ):
        return "refuerzo_afectivo"

    # JUEGO

    if contiene_alguna(
        texto,
        [
            "jaja",
            "jajaja",
            "xd",
            "😂",
            "🤣"
        ]
    ):
        return "juego"

    # COMPARTIR

    if contiene_alguna(
        texto,
        [
            "te voy a contar",
            "mira esto",
            "adivina",
            "sabes qué",
            "sabes que"
        ]
    ):
        return "compartir"

    return "conversacion"


# ============================================================
# DETECTAR EMOCIONES CONTEXTUALES
# ============================================================

def detectar_emociones_contextuales(texto):

    texto = normalizar_texto(texto)

    emociones = {
        "felicidad": 0,
        "tristeza": 0,
        "enojo": 0,
        "sorpresa": 0,
        "afecto": 0,
        "curiosidad": 0,
        "diversion": 0
    }

    # --------------------------------------------------------
    # AFECTO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "te quiero",
            "te amo",
            "amor",
            "cariño",
            "me importas",
            "te extraño",
            "te extrano"
        ]
    ):
        emociones["afecto"] = 30

    # --------------------------------------------------------
    # TRISTEZA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "estoy triste",
            "me siento triste",
            "estoy mal",
            "me siento mal",
            "estoy solo",
            "estoy sola",
            "me duele"
        ]
    ):
        emociones["tristeza"] = 40

    # --------------------------------------------------------
    # ENOJO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "estoy enojado",
            "estoy enojada",
            "me molesta",
            "estoy harto",
            "estoy harta",
            "qué mierda",
            "que mierda",
            "carajo"
        ]
    ):
        emociones["enojo"] = 45

    # --------------------------------------------------------
    # DIVERSIÓN
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "jaja",
            "jajaja",
            "xd",
            "😂",
            "🤣",
            "broma",
            "juego"
        ]
    ):
        emociones["diversion"] = 40
        emociones["felicidad"] = 25

    # --------------------------------------------------------
    # SORPRESA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "wow",
            "no puede ser",
            "en serio",
            "enserio"
        ]
    ):
        emociones["sorpresa"] = 20

    # --------------------------------------------------------
    # CURIOSIDAD
    # --------------------------------------------------------

    if "?" in texto:
        emociones["curiosidad"] = 25

    return emociones


# ============================================================
# DETECTAR AMENAZA RELACIONAL
# ============================================================

def detectar_amenaza_relacional(texto):

    texto = normalizar_texto(texto)

    palabras = [
        "otra chica",
        "otra mujer",
        "otro chico",
        "otro hombre",
        "mi novia",
        "mi novio",
        "una chica",
        "un chico",
        "salí con",
        "sali con",
        "me gusta otra",
        "me gusta otro"
    ]

    if contiene_alguna(texto, palabras):

        return {
            "amenaza_relacional": True,
            "intensidad": 60
        }

    return {
        "amenaza_relacional": False,
        "intensidad": 0
    }


# ============================================================
# DETECTAR ESTADO RELACIONAL
# ============================================================

def detectar_estado_relacional(texto):

    texto = normalizar_texto(texto)

    # RECONCILIACIÓN

    if contiene_alguna(
        texto,
        [
            "perdón",
            "perdon",
            "lo siento",
            "disculpa",
            "disculpame",
            "discúlpame",
            "hagamos las paces"
        ]
    ):
        return ESTADO_RECONCILIACION

    # DISCUSIÓN

    if contiene_alguna(
        texto,
        [
            "estoy enojado",
            "estoy enojada",
            "me molesta",
            "no estoy de acuerdo",
            "déjame",
            "dejame",
            "cállate",
            "callate"
        ]
    ):
        return ESTADO_DISCUSSION

    # DISTANCIA

    if contiene_alguna(
        texto,
        [
            "necesito espacio",
            "déjame solo",
            "dejame solo",
            "déjame tranquila",
            "dejame tranquila",
            "no quiero hablar"
        ]
    ):
        return ESTADO_DISTANTE

    return ESTADO_NORMAL


# ============================================================
# DETECTAR EVENTO RELACIONAL
# ============================================================

def detectar_evento_relacional(texto):

    texto = normalizar_texto(texto)

    # --------------------------------------------------------
    # RECONCILIACIÓN
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "perdón",
            "perdon",
            "lo siento",
            "disculpa",
            "disculpame",
            "discúlpame",
            "hagamos las paces"
        ]
    ):
        return {
            "evento": "reconciliacion",
            "intensidad": 60
        }

    # --------------------------------------------------------
    # APOYO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "te apoyo",
            "estoy contigo",
            "cuenta conmigo",
            "no estás sola",
            "no estas sola",
            "no te voy a dejar"
        ]
    ):
        return {
            "evento": "apoyo",
            "intensidad": 60
        }

    # --------------------------------------------------------
    # AFECTO
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "te quiero",
            "te amo",
            "me importas",
            "te extraño",
            "te extrano"
        ]
    ):
        return {
            "evento": "gesto_carinoso",
            "intensidad": 60
        }

    # --------------------------------------------------------
    # PROMESA CUMPLIDA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "cumplí",
            "cumpli",
            "lo prometido",
            "cumplí mi promesa",
            "cumpli mi promesa"
        ]
    ):
        return {
            "evento": "cumplio_promesa",
            "intensidad": 70
        }

    # --------------------------------------------------------
    # ROMPER PROMESA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "rompí mi promesa",
            "rompi mi promesa",
            "no cumplí",
            "no cumpli"
        ]
    ):
        return {
            "evento": "romper_promesa",
            "intensidad": 70
        }

    # --------------------------------------------------------
    # MENTIRA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "te mentí",
            "te menti",
            "era mentira",
            "te engañé",
            "te engañe"
        ]
    ):
        return {
            "evento": "mentira",
            "intensidad": 80
        }

    # --------------------------------------------------------
    # DISTANCIA
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "no quiero hablar",
            "déjame solo",
            "dejame solo",
            "necesito espacio"
        ]
    ):
        return {
            "evento": "ignorar",
            "intensidad": 50
        }

    # --------------------------------------------------------
    # DISCUSIÓN
    # --------------------------------------------------------

    if contiene_alguna(
        texto,
        [
            "estoy enojado",
            "estoy enojada",
            "me molesta",
            "no estoy de acuerdo"
        ]
    ):
        return {
            "evento": "discusion",
            "intensidad": 50
        }

    # --------------------------------------------------------
    # SIN EVENTO
    # --------------------------------------------------------

    return {
        "evento": None,
        "intensidad": 0
    }


# ============================================================
# ANALIZAR CONTEXTO COMPLETO
# ============================================================

def analizar_contexto(texto):

    tono = detectar_tono(texto)

    intencion = detectar_intencion(texto)

    emociones = detectar_emociones_contextuales(
        texto
    )

    amenaza = detectar_amenaza_relacional(
        texto
    )

    estado_relacional = detectar_estado_relacional(
        texto
    )

    evento_relacional = detectar_evento_relacional(
        texto
    )

    return {

        "situacion": estado_relacional,

        "tono": tono,

        "intencion": intencion,

        "emociones": emociones,

        "contexto_relacional": amenaza,

        "estado_relacional": estado_relacional,

        "evento_relacional": evento_relacional
    }


# ============================================================
# COMPATIBILIDAD
# ============================================================

def detectar_contexto(texto):

    return analizar_contexto(texto)


# ============================================================
# DEBUG
# ============================================================

def imprimir_contexto(texto):

    contexto = analizar_contexto(texto)

    print()
    print("==============================================")
    print("           CONTEXTO DETECTADO")
    print("==============================================")

    print()
    print("MENSAJE:")
    print(texto)

    print()
    print("SITUACIÓN:")
    print(contexto["situacion"])

    print()
    print("TONO:")
    print(contexto["tono"])

    print()
    print("INTENCIÓN:")
    print(contexto["intencion"])

    print()
    print("EMOCIONES:")
    print(contexto["emociones"])

    print()
    print("CONTEXTO RELACIONAL:")
    print(contexto["contexto_relacional"])

    print()
    print("ESTADO RELACIONAL:")
    print(contexto["estado_relacional"])

    print()
    print("EVENTO RELACIONAL:")
    print(contexto["evento_relacional"])

    print()
    print("==============================================")


# ============================================================
# PRUEBA DIRECTA
# ============================================================

if __name__ == "__main__":

    mensajes_prueba = [

        "Hola Eli",

        "Jajaja mira esto 😂",

        "Hoy me siento bastante mal",

        "Estoy enojado contigo",

        "Perdón Eli, no quería hacerlo",

        "Me gusta otra chica",

        "Necesito espacio",

        "Te quiero mucho",

        "Cumplí mi promesa",

        "Te mentí"
    ]

    for mensaje in mensajes_prueba:

        imprimir_contexto(mensaje)
