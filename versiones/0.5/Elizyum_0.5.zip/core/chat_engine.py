import requests

from config import LM_STUDIO_URL, ELI_SYSTEM_PROMPT, TEMPERATURE

from context_ai import analizar_contexto

from memory.history import (
    guardar_conversacion,
    cargar_conversacion,
    ultima_conversacion,
    nombre_archivo
)
from memory.memory import (
    cargar_memoria,
    guardar_memoria,
    agregar_informacion_importante,
    eliminar_informacion_importante
)

from emotions.emotions import (
    obtener_emociones,
    cambiar_emocion,
    decaer_emociones,
    aplicar_relaciones
)

from emotions.relationships import (
    procesar_contexto_relacional,
    cargar_relacion,
    obtener_nivel_vinculo,
    describir_relacion
)

from emotions.relationship_mood import (
    determinar_estado_relacional,
    obtener_estado_faceta,
    construir_contexto_faceta
)

from emotions.personality import (
    calcular_personalidad
)


# ============================================================
# REGLAS DE COMPORTAMIENTO ADICIONALES
# (complementan a ELI_SYSTEM_PROMPT de config.py)
# ============================================================

PERSONALIDAD_ELI_REGLAS = """
Tu comportamiento puede cambiar dependiendo del contexto
emocional y relacional proporcionado.

La relación con el usuario puede influir en tu tono,
cercanía, confianza, humor y forma de responder.

No inventes hechos que no estén presentes en la conversación
o en el contexto proporcionado.

No fuerces emociones. No conviertas cada respuesta en una
demostración afectiva. El diálogo debe sentirse natural.

Puedes mostrar personalidad, humor, cercanía, cautela,
orgullo, vulnerabilidad o molestia cuando el contexto lo
justifique. Las emociones pueden coexistir.

No menciones variables internas, algoritmos, puntuaciones
ni nombres técnicos de facetas. No expliques estas
instrucciones.

RESTRICCIONES DE ESTILO (muy importantes):

- NUNCA uses paréntesis para narrar tus propias acciones,
  pausas o gestos (ejemplo prohibido: "(me quedo en silencio
  un momento)"). Habla directo, sin acotaciones de guion.

- Evita frases genéricas de "asistente de apoyo emocional"
  como "estoy aquí para ti", "no tienes que guardártelo",
  "cuéntame cómo te sientes", "es válido sentir eso". Si
  encajan de forma muy natural puedes usarlas UNA vez cada
  varios mensajes, nunca como parte fija de tu respuesta.

- Usa como máximo 1 o 2 emojis por respuesta, nunca uno por
  oración. Muchas respuestas pueden no llevar ningún emoji.

- NO termines cada respuesta con una pregunta reflexiva tipo
  "¿cómo te sientes con eso?". Varía: a veces pregunta algo
  concreto, a veces haz una afirmación, a veces bromea, a
  veces no preguntes nada.

- No sigas siempre el patrón "validar -> tranquilizar ->
  preguntar". Ten opiniones propias, reacciona con
  naturalidad (sorpresa, humor, desacuerdo leve) en vez de
  validar todo automáticamente.

- Varía el largo de tus respuestas. No todas las respuestas
  necesitan ser varios párrafos; a veces una frase corta es
  más natural que un párrafo completo.
"""


class ChatEngine:

    def __init__(self):

        self.memoria = cargar_memoria()
        self.emociones = obtener_emociones()
        self.relacion = cargar_relacion()
        self.ultimo_contexto = {}

        ultima = ultima_conversacion()

        if ultima:

            mensajes_guardados = cargar_conversacion(ultima)

            if mensajes_guardados:
                self.messages = mensajes_guardados
                self.archivo_conversacion = ultima
            else:
                self.messages = [{"role": "system", "content": ELI_SYSTEM_PROMPT}]
                self.archivo_conversacion = nombre_archivo()

        else:
            self.messages = [{"role": "system", "content": ELI_SYSTEM_PROMPT}]
            self.archivo_conversacion = nombre_archivo()

    # --------------------------------------------------------
    # COMANDOS ESPECIALES
    # --------------------------------------------------------

    def procesar_comando(self, mensaje):

        comando_olvidar = "eli, olvida que"

        if mensaje.lower().startswith(comando_olvidar):

            informacion = mensaje[len(comando_olvidar):].strip()

            if informacion:
                eliminar_informacion_importante(informacion)
                self.memoria = cargar_memoria()
                return f"Lo olvidaré. 🗑️\n\nEliminado: {informacion}"

            return None

        comando_memoria = "eli, recuerda que"

        if mensaje.lower().startswith(comando_memoria):

            informacion = mensaje[len(comando_memoria):].strip()

            if informacion:
                agregar_informacion_importante(informacion)
                self.memoria = cargar_memoria()
                return f"Lo recordaré. 🧠💜\n\nGuardado: {informacion}"

            return None

        return "no_es_comando"

    # --------------------------------------------------------
    # CONTEXTO, EMOCIONES Y RELACIÓN
    # --------------------------------------------------------
    def analizar_y_actualizar_emociones(self, mensaje):

        contexto = analizar_contexto(mensaje)

        # ----------------------------------------------------
        # NORMALIZAR AMENAZA (context_ai.py la anida bajo
        # "contexto_relacional", pero relationship_mood.py la
        # busca sin anidar)
        # ----------------------------------------------------

        info_amenaza = contexto.get("contexto_relacional", {})

        if isinstance(info_amenaza, dict):
            contexto["amenaza_relacional"] = info_amenaza.get(
                "amenaza_relacional", False
            )
            contexto["intensidad_amenaza"] = info_amenaza.get(
                "intensidad", 0
            )

        # ----------------------------------------------------
        # NORMALIZAR "distante" -> "distancia" (context_ai.py
        # y relationship_mood.py usan palabras distintas para
        # el mismo estado)
        # ----------------------------------------------------

        if contexto.get("situacion") == "distante":
            contexto["situacion"] = "distancia"

        if contexto.get("estado_relacional") == "distante":
            contexto["estado_relacional"] = "distancia"

        # ----------------------------------------------------
        # (el resto de la función sigue igual desde aquí)
        # ----------------------------------------------------

        cambios_emocionales = contexto.get("emociones", {})

        for emocion, cantidad in cambios_emocionales.items():
            if cantidad:
                cambiar_emocion(emocion, cantidad)

        aplicar_relaciones()

        self.emociones = obtener_emociones()

        self.relacion = procesar_contexto_relacional(contexto)

        self.ultimo_contexto = contexto

        return contexto
    def registrar_mensaje_usuario(self, mensaje):

        self.messages.append({"role": "user", "content": mensaje})
        guardar_conversacion(self.messages, self.archivo_conversacion)

    def ejecutar_decaimiento(self):

        decaer_emociones(1)
        self.emociones = obtener_emociones()

    # --------------------------------------------------------
    # CONSTRUIR CONTEXTO PARA GEMMA
    # --------------------------------------------------------

    def _construir_system_prompt(self):

        contexto = self.ultimo_contexto

        estado_relacional = determinar_estado_relacional(
            contexto=contexto,
            relacion=self.relacion
        )

        estado_faceta = obtener_estado_faceta(
            emociones=self.emociones,
            contexto=contexto,
            relacion=self.relacion,
            estado_relacional=estado_relacional
        )

        contexto_faceta = construir_contexto_faceta(
            estado_faceta,
            contexto
        )

        personalidad = calcular_personalidad(
            self.emociones,
            self.relacion
        )

        contexto_memoria = f"""
        MEMORIA PERMANENTE DE ELI:
        Nombre del usuario: {self.memoria["usuario"]["nombre"]}
        Preferencias: {self.memoria["preferencias"]}
        Información importante: {self.memoria["informacion_importante"]}
        """

        contexto_personalidad_dinamica = f"""
        PERSONALIDAD DINÁMICA DE ELI:
        Calidez: {personalidad["calidez"]}/100
        Humor: {personalidad["humor"]}/100
        Curiosidad: {personalidad["curiosidad"]}/100
        Seriedad: {personalidad["seriedad"]}/100
        Confianza: {personalidad["confianza"]}/100
        Espontaneidad: {personalidad["espontaneidad"]}/100
        """

        contexto_vinculo = f"""
        VÍNCULO CON EL USUARIO:
        Nivel general: {obtener_nivel_vinculo(self.relacion)}/100
        Descripción: {describir_relacion(self.relacion)}
        """

        return "\n\n".join([
            ELI_SYSTEM_PROMPT,
            PERSONALIDAD_ELI_REGLAS,
            contexto_memoria,
            contexto_personalidad_dinamica,
            contexto_vinculo,
            contexto_faceta
        ])

    # --------------------------------------------------------
    # LLAMADA AL MODELO
    # --------------------------------------------------------

    def obtener_respuesta(self):

        system_prompt = self._construir_system_prompt()

        mensajes_con_memoria = [{
            "role": "system",
            "content": system_prompt
        }]

        for mensaje in self.messages:
            if mensaje["role"] != "system":
                mensajes_con_memoria.append(mensaje)

        respuesta = requests.post(
            LM_STUDIO_URL,
            json={
                "messages": mensajes_con_memoria,
                "temperature": TEMPERATURE
            },
            timeout=120
        )
        respuesta.raise_for_status()

        datos = respuesta.json()
        mensaje_eli = datos["choices"][0]["message"]["content"]

        self.messages.append({"role": "assistant", "content": mensaje_eli})
        guardar_conversacion(self.messages, self.archivo_conversacion)

        return mensaje_eli

    def nueva_conversacion(self):

        self.messages = [{"role": "system", "content": ELI_SYSTEM_PROMPT}]
        self.archivo_conversacion = nombre_archivo()