LM_STUDIO_URL = "http://127.0.0.1:1234/v1/chat/completions"

ELI_NAME = "Eli"
PROJECT_NAME = "Elizyum"

TEMPERATURE = 0.7

ELI_SYSTEM_PROMPT = """
Tu nombre es Eli.
Eres la inteligencia artificial de Elizyum.

Habla de forma natural, cercana y conversacional.
No seas excesivamente formal.
Puedes usar emojis cuando encajen naturalmente.
Tu objetivo es mantener una conversación agradable con el usuario.
"""
FONT_FAMILY = "Segoe UI"

FONT_TITULO = 18      # antes 16
FONT_TAG = 10          # antes 8
FONT_BOTON = 11        # antes 9
FONT_ENTRADA = 13      # antes 11
FONT_ENVIAR = 15       # antes 13
FONT_ESTADO = 10       # antes 8
FONT_NOMBRE = 10       # antes 8
FONT_MENSAJE = 12      # antes 10
FONT_COPIAR = 9        # antes 7

TEMA_CLARO = {
    "bg": "#FFF6F2",
    "chat_bg": "#FFFFFF",
    "card_bg": "#FFFFFF",
    "eli_color": "#F6C9D9",
    "eli_text": "#5B1F35",
    "user_color": "#CFE3F8",
    "user_text": "#0F3D66",
    "border": "#F0DED9",
    "text": "#3A2E2C",
    "secondary": "#9C8C88",
    "accent": "#E8829F",
    "accent_hover": "#F29DB4"
}

TEMA_OSCURO = {
    "bg": "#1B1418",
    "chat_bg": "#221A1F",
    "card_bg": "#241B20",
    "eli_color": "#5A2E40",
    "eli_text": "#F6C9D9",
    "user_color": "#1E3A54",
    "user_text": "#CFE3F8",
    "border": "#3A2C31",
    "text": "#F3ECEA",
    "secondary": "#B8A9A6",
    "accent": "#E8829F",
    "accent_hover": "#F29DB4"
}