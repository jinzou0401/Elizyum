import tkinter as tk
from tkinter import messagebox
import threading

from config import (
    FONT_FAMILY,
    FONT_TITULO,
    FONT_TAG,
    FONT_BOTON,
    FONT_ENTRADA,
    FONT_ENVIAR,
    FONT_ESTADO,
    FONT_NOMBRE,
    FONT_MENSAJE,
    FONT_COPIAR,
    TEMA_CLARO,
    TEMA_OSCURO
)


class ChatWindow:

    def __init__(self, root, motor):

        self.root = root
        self.motor = motor

        self.modo_oscuro = False
        self.tema = TEMA_CLARO

        self.root.configure(bg=self.tema["bg"])
        self.root.title("Elizyum — Eli")
        self.root.geometry("980x720")
        self.root.minsize(720, 520)

        self.crear_interfaz()
        self.mostrar_historial()
        self.ejecutar_decaimiento_emocional()

    # ========================================================
    # INTERFAZ
    # ========================================================

    def crear_interfaz(self):
        t = self.tema

        # ----------------------------------------------------
        # ENCABEZADO
        # ----------------------------------------------------
        self.header = tk.Frame(self.root, bg=t["bg"], height=65)
        self.header.pack(fill=tk.X, padx=20)
        self.header.pack_propagate(False)

        self.info_frame = tk.Frame(self.header, bg=t["bg"])
        self.info_frame.pack(side=tk.LEFT, fill=tk.Y)

        self.titulo = tk.Label(
            self.info_frame,
            text="Eli",
            bg=t["bg"],
            fg=t["text"],
            font=(FONT_FAMILY, FONT_TITULO, "bold")
        )
        self.titulo.pack(side=tk.LEFT, pady=18)

        self.tag = tk.Label(
            self.info_frame,
            text="AI",
            bg=t["accent"],
            fg="#ffffff",
            font=(FONT_FAMILY, FONT_TAG, "bold"),
            padx=5,
            pady=1
        )
        self.tag.pack(side=tk.LEFT, padx=(8, 10), pady=18)

        self.btn_limpiar = tk.Button(
            self.header,
            text="+ Nueva conversación",
            bg=t["card_bg"],
            fg=t["text"],
            activebackground=t["accent"],
            activeforeground="white",
            relief=tk.FLAT,
            borderwidth=0,
            cursor="hand2",
            padx=14,
            pady=6,
            command=self.nueva_conversacion,
            font=(FONT_FAMILY, FONT_BOTON)
        )
        self.btn_limpiar.pack(side=tk.RIGHT, pady=16)
        self._add_hover_effect(self.btn_limpiar, "card_bg", "border")

        self.btn_tema = tk.Button(
            self.header,
            text="🌙 Oscuro",
            bg=t["card_bg"],
            fg=t["text"],
            activebackground=t["accent"],
            activeforeground="white",
            relief=tk.FLAT,
            borderwidth=0,
            cursor="hand2",
            padx=14,
            pady=6,
            command=self.alternar_tema,
            font=(FONT_FAMILY, FONT_BOTON)
        )
        self.btn_tema.pack(side=tk.RIGHT, padx=(0, 8), pady=16)
        self._add_hover_effect(self.btn_tema, "card_bg", "border")

        # ----------------------------------------------------
        # ZONA DEL CHAT
        # ----------------------------------------------------
        self.chat_card = tk.Frame(self.root, bg=t["border"], padx=1, pady=1)
        self.chat_card.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))

        self.chat_frame = tk.Frame(self.chat_card, bg=t["chat_bg"])
        self.chat_frame.pack(fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(self.chat_frame, bg=t["chat_bg"], highlightthickness=0)
        self.contenedor_mensajes = tk.Frame(self.canvas, bg=t["chat_bg"])

        self.contenedor_mensajes.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window(
            (0, 0),
            window=self.contenedor_mensajes,
            anchor="nw"
        )

        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self.actualizar_ancho)

        self.root.bind_all("<MouseWheel>", self._on_mousewheel)

        # ----------------------------------------------------
        # ENTRADA DE TEXTO
        # ----------------------------------------------------
        self.input_container = tk.Frame(self.root, bg=t["bg"])
        self.input_container.pack(fill=tk.X, padx=20, pady=(0, 8))

        self.input_card = tk.Frame(self.input_container, bg=t["border"], padx=1, pady=1)
        self.input_card.pack(fill=tk.X)

        self.inner_input = tk.Frame(self.input_card, bg=t["card_bg"])
        self.inner_input.pack(fill=tk.X)

        self.entrada = tk.Entry(
            self.inner_input,
            bg=t["card_bg"],
            fg=t["text"],
            insertbackground=t["text"],
            relief=tk.FLAT,
            borderwidth=0,
            font=(FONT_FAMILY, FONT_ENTRADA)
        )
        self.entrada.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=14, ipady=11)
        self.entrada.bind("<Return>", lambda event: self.enviar_mensaje())
        self.entrada.bind("<FocusIn>", lambda e: self.input_card.config(bg=self.tema["accent"]))
        self.entrada.bind("<FocusOut>", lambda e: self.input_card.config(bg=self.tema["border"]))

        self.boton_enviar = tk.Button(
            self.inner_input,
            text="↑",
            bg=t["accent"],
            fg="white",
            activebackground=t["accent_hover"],
            relief=tk.FLAT,
            borderwidth=0,
            cursor="hand2",
            font=(FONT_FAMILY, FONT_ENVIAR, "bold"),
            command=self.enviar_mensaje,
            padx=14,
            pady=2
        )
        self.boton_enviar.pack(side=tk.RIGHT, padx=8, pady=6)
        self._add_hover_effect(self.boton_enviar, "accent", "accent_hover")

        # ----------------------------------------------------
        # INDICADOR INFERIOR
        # ----------------------------------------------------
        self.estado = tk.Label(
            self.root,
            text="Eli está lista ✨",
            bg=t["bg"],
            fg=t["secondary"],
            font=(FONT_FAMILY, FONT_ESTADO)
        )
        self.estado.pack(pady=(0, 6))

        if len(self.motor.messages) <= 1:
            self.mostrar_mensaje("Eli", "¡Hola! 👋 Soy Eli.\n¿De qué te gustaría hablar hoy?")

        self.entrada.focus()

    # ========================================================
    # TEMA (CLARO / OSCURO)
    # ========================================================

    def alternar_tema(self):
        self.modo_oscuro = not self.modo_oscuro
        self.tema = TEMA_OSCURO if self.modo_oscuro else TEMA_CLARO
        self.repintar_interfaz()

    def repintar_interfaz(self):
        t = self.tema

        self.root.configure(bg=t["bg"])
        self.header.configure(bg=t["bg"])
        self.info_frame.configure(bg=t["bg"])
        self.titulo.configure(bg=t["bg"], fg=t["text"])
        self.tag.configure(bg=t["accent"])

        self.btn_limpiar.configure(bg=t["card_bg"], fg=t["text"], activebackground=t["accent"])
        self.btn_tema.configure(
            bg=t["card_bg"],
            fg=t["text"],
            activebackground=t["accent"],
            text="☀️ Claro" if self.modo_oscuro else "🌙 Oscuro"
        )

        self.chat_card.configure(bg=t["border"])
        self.chat_frame.configure(bg=t["chat_bg"])
        self.canvas.configure(bg=t["chat_bg"])
        self.contenedor_mensajes.configure(bg=t["chat_bg"])

        self.input_container.configure(bg=t["bg"])
        self.input_card.configure(bg=t["border"])
        self.inner_input.configure(bg=t["card_bg"])
        self.entrada.configure(bg=t["card_bg"], fg=t["text"], insertbackground=t["text"])

        self.boton_enviar.configure(bg=t["accent"], activebackground=t["accent_hover"])
        self.estado.configure(bg=t["bg"], fg=t["secondary"])

        for widget in self.contenedor_mensajes.winfo_children():
            widget.destroy()

        self.mostrar_historial()

    # ========================================================
    # HELPERS VISUALES
    # ========================================================

    def _add_hover_effect(self, widget, clave_normal, clave_hover):
        widget.bind("<Enter>", lambda e: widget.config(bg=self.tema[clave_hover]))
        widget.bind("<Leave>", lambda e: widget.config(bg=self.tema[clave_normal]))

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def actualizar_ancho(self, event):
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    # ========================================================
    # MENSAJES Y CHAT
    # ========================================================

    def copiar_al_portapapeles(self, texto):
        self.root.clipboard_clear()
        self.root.clipboard_append(texto)
        self.estado.config(text="Copiado al portapapeles 📋")
        self.root.after(2000, lambda: self.estado.config(text="Eli está lista ✨"))

    def mostrar_historial(self):
        for mensaje in self.motor.messages:
            if mensaje["role"] == "user":
                self.mostrar_mensaje("Tú", mensaje["content"])
            elif mensaje["role"] == "assistant":
                self.mostrar_mensaje("Eli", mensaje["content"])

    def mostrar_mensaje(self, autor, mensaje):
        t = self.tema
        es_eli = (autor == "Eli" or autor == "Elizyum")

        contenedor = tk.Frame(self.contenedor_mensajes, bg=t["chat_bg"])
        contenedor.pack(fill=tk.X, padx=18, pady=5)

        burbuja_bg = t["eli_color"] if es_eli else t["user_color"]
        texto_fg = t["eli_text"] if es_eli else t["user_text"]

        burbuja = tk.Frame(
            contenedor,
            bg=burbuja_bg,
            padx=14,
            pady=10
        )
        burbuja.pack(anchor="w" if es_eli else "e", padx=5)

        nombre = tk.Label(
            burbuja,
            text=autor,
            bg=burbuja_bg,
            fg=texto_fg,
            font=(FONT_FAMILY, FONT_NOMBRE, "bold")
        )
        nombre.pack(anchor="w", pady=(0, 4))

        wrap_calc = max(400, self.root.winfo_width() - 220)
        texto = tk.Label(
            burbuja,
            text=mensaje,
            bg=burbuja_bg,
            fg=texto_fg,
            font=(FONT_FAMILY, FONT_MENSAJE),
            justify=tk.LEFT,
            anchor="w",
            wraplength=wrap_calc
        )
        texto.pack(anchor="w", pady=(0, 4))

        boton_copiar = tk.Button(
            burbuja,
            text="Copiar",
            bg=burbuja_bg,
            fg=texto_fg,
            activebackground=burbuja_bg,
            activeforeground=texto_fg,
            relief=tk.FLAT,
            borderwidth=0,
            font=(FONT_FAMILY, FONT_COPIAR),
            cursor="hand2",
            command=lambda t=mensaje: self.copiar_al_portapapeles(t)
        )
        boton_copiar.pack(anchor="e")

        self.root.after(50, lambda: self.canvas.yview_moveto(1.0))

    # ========================================================
    # ENVÍO DE MENSAJES (ahora delega en self.motor)
    # ========================================================

    def ejecutar_decaimiento_emocional(self):
        self.motor.ejecutar_decaimiento()
        self.root.after(30000, self.ejecutar_decaimiento_emocional)

    def enviar_mensaje(self):
        mensaje = self.entrada.get().strip()
        if not mensaje:
            return

        resultado_comando = self.motor.procesar_comando(mensaje)

        if resultado_comando != "no_es_comando":
            self.entrada.delete(0, tk.END)
            self.mostrar_mensaje("Tú", mensaje)
            if resultado_comando:
                self.mostrar_mensaje("Eli", resultado_comando)
            return

        self.entrada.delete(0, tk.END)
        self.mostrar_mensaje("Tú", mensaje)

        self.motor.analizar_y_actualizar_emociones(mensaje)
        self.motor.registrar_mensaje_usuario(mensaje)

        self.estado.config(text="Eli está pensando... 💭")
        self.boton_enviar.config(state=tk.DISABLED)

        threading.Thread(target=self.obtener_respuesta, daemon=True).start()

    def obtener_respuesta(self):
        try:
            mensaje_eli = self.motor.obtener_respuesta()
            self.root.after(0, lambda: self.finalizar_respuesta(mensaje_eli))
        except Exception as error:
            self.root.after(0, lambda: self.mostrar_error(str(error)))

    def finalizar_respuesta(self, mensaje):
        self.mostrar_mensaje("Eli", mensaje)
        self.estado.config(text="Eli está lista ✨")
        self.boton_enviar.config(state=tk.NORMAL)
        self.entrada.focus()

    def mostrar_error(self, error):
        self.mostrar_mensaje("Elizyum", f"No pude conectarme con LM Studio.\n\nError: {error}")
        self.estado.config(text="Error de conexión ⚠️")
        self.boton_enviar.config(state=tk.NORMAL)

    def nueva_conversacion(self):
        confirmar = messagebox.askyesno("Nueva conversación", "¿Quieres comenzar una nueva conversación?")
        if not confirmar:
            return

        self.motor.nueva_conversacion()

        for widget in self.contenedor_mensajes.winfo_children():
            widget.destroy()

        self.mostrar_mensaje("Eli", "Conversación nueva ✨\n¿Qué hacemos ahora?")
        self.estado.config(text="Eli está lista ✨")