# ============================================================
# SISTEMA EMOCIONAL DE ELI
# ============================================================
import json
from pathlib import Path
from emotions.emotion_links import aplicar_relaciones_emocionales

BASE_DIR = Path(__file__).resolve().parent.parent
EMOTIONS_FILE = BASE_DIR / "data" / "memory" / "eli_emotions.json"

# ============================================================
# ESTADO BASE
# ============================================================

EMOCIONES_BASE = {

    "felicidad": 50,
    "tristeza": 0,
    "enojo": 0,
    "sorpresa": 0,
    "afecto": 50,
    "curiosidad": 50,
    "diversion": 30
}

# ============================================================
# GUARDAR Y CARGAR EMOCIONES
# ============================================================

def cargar_emociones():

    if not EMOTIONS_FILE.exists():
        return EMOCIONES_BASE.copy()

    try:

        with open(
            EMOTIONS_FILE,
            "r",
            encoding="utf-8"
        ) as archivo:

            datos = json.load(archivo)

        return {**EMOCIONES_BASE, **datos}

    except Exception:

        return EMOCIONES_BASE.copy()


def guardar_emociones(datos):

    EMOTIONS_FILE.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(
        EMOTIONS_FILE,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            datos,
            archivo,
            ensure_ascii=False,
            indent=4
        )

# ------------------------------------------------------------
# ESTADO EMOCIONAL INICIAL
# ------------------------------------------------------------

emociones = cargar_emociones()


# ------------------------------------------------------------
# OBTENER EMOCIONES
# ------------------------------------------------------------

def obtener_emociones():

    return emociones.copy()


# ------------------------------------------------------------
# CAMBIAR UNA EMOCIÓN
# ------------------------------------------------------------

def cambiar_emocion(nombre, cantidad):

    if nombre not in emociones:
        return emociones.copy()

    emociones[nombre] += cantidad

    # Mantener el valor entre 0 y 100

    if emociones[nombre] < 0:
        emociones[nombre] = 0

    if emociones[nombre] > 100:
        emociones[nombre] = 100

    guardar_emociones(emociones)

    return emociones.copy()


# ------------------------------------------------------------
# ESTABLECER UNA EMOCIÓN
# ------------------------------------------------------------

def establecer_emocion(nombre, valor):

    if nombre not in emociones:
        return emociones.copy()

    if valor < 0:
        valor = 0

    if valor > 100:
        valor = 100

    emociones[nombre] = valor

    guardar_emociones(emociones)

    return emociones.copy()

# ------------------------------------------------------------
# EMOCIÓN DOMINANTE
# ------------------------------------------------------------

def emocion_dominante():

    return max(
        emociones,
        key=emociones.get
    )


# ------------------------------------------------------------
# DESCRIPCIÓN DEL ESTADO EMOCIONAL
# ------------------------------------------------------------

def describir_estado_emocional():

    dominante = emocion_dominante()
    intensidad = emociones[dominante]

    return {
        "emocion": dominante,
        "intensidad": intensidad
    }


def decaer_emociones(cantidad=1):

    for nombre in emociones:

        base = EMOCIONES_BASE[nombre]

        if emociones[nombre] > base:

            emociones[nombre] -= cantidad

            if emociones[nombre] < base:
                emociones[nombre] = base

        elif emociones[nombre] < base:

            emociones[nombre] += cantidad

            if emociones[nombre] > base:
                emociones[nombre] = base

    relacionadas = aplicar_relaciones_emocionales(emociones)
    emociones.update(relacionadas)

    guardar_emociones(emociones)

    return emociones.copy()


# ------------------------------------------------------------
# APLICAR RELACIONES (llamar UNA sola vez por mensaje, no por
# cada cambiar_emocion individual, para evitar retroalimentación
# descontrolada)
# ------------------------------------------------------------

def aplicar_relaciones():

    relacionadas = aplicar_relaciones_emocionales(emociones)
    emociones.update(relacionadas)

    guardar_emociones(emociones)

    return emociones.copy()


# ============================================================
# ESTADO DE ÁNIMO
# ============================================================

def obtener_estado_animo():

    felicidad = emociones["felicidad"]
    tristeza = emociones["tristeza"]
    enojo = emociones["enojo"]
    afecto = emociones["afecto"]
    curiosidad = emociones["curiosidad"]
    diversion = emociones["diversion"]

    # --------------------------------------------------------
    # CALCULAR ÁNIMO POSITIVO
    # --------------------------------------------------------

    positivo = (
        felicidad
        + afecto
        + curiosidad
        + diversion
    ) / 4

    # --------------------------------------------------------
    # CALCULAR ÁNIMO NEGATIVO
    # --------------------------------------------------------

    negativo = (
        tristeza
        + enojo
    ) / 2

    # --------------------------------------------------------
    # DETERMINAR ÁNIMO
    # --------------------------------------------------------

    diferencia = positivo - negativo

    if diferencia >= 40:

        estado = "muy alegre"

    elif diferencia >= 20:

        estado = "alegre"

    elif diferencia >= 5:

        estado = "tranquila"

    elif diferencia > -10:

        estado = "neutral"

    elif diferencia > -30:

        estado = "melancólica"

    else:

        estado = "molesta"

    # --------------------------------------------------------
    # INTENSIDAD DEL ÁNIMO
    # --------------------------------------------------------

    intensidad = abs(diferencia)

    if intensidad > 100:
        intensidad = 100

    return {
        "estado": estado,
        "intensidad": round(intensidad)
    }

# ============================================================
# PERSONALIDAD BASE DE ELI
# ============================================================

PERSONALIDAD_ELI = {

    "calidez": 70,
    "humor": 65,
    "curiosidad": 75,
    "seriedad": 45,
    "confianza": 60,
    "espontaneidad": 65

}