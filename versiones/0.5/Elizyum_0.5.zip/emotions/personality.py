# emotions/personality.py

"""
Personalidad dinámica de Eli.

La personalidad de Eli depende de:

1. Personalidad base
2. Estado emocional actual
3. Estado actual de la relación con el usuario

Las emociones representan cómo se siente Eli.
La relación representa cómo evoluciona el vínculo.
La personalidad transforma ambos estados en comportamiento.

Este módulo NO modifica emociones ni relación.
Solamente los lee.
"""


# ============================================================
# PERSONALIDAD BASE
# ============================================================

PERSONALIDAD_BASE = {
    "calidez": 70,
    "humor": 65,
    "curiosidad": 75,
    "seriedad": 45,
    "confianza": 60,
    "espontaneidad": 65,
}


# ============================================================
# LIMITES
# ============================================================

MINIMO = 0
MAXIMO = 100


def limitar(valor):
    """Mantiene un valor dentro del rango 0-100."""
    return max(
        MINIMO,
        min(MAXIMO, int(round(valor)))
    )


# ============================================================
# PERSONALIDAD DINÁMICA
# ============================================================
def calcular_personalidad(emociones, relacion=None):
    """
    Calcula la personalidad dinámica de Eli.

    La personalidad depende de:

    - Personalidad base
    - Emociones actuales
    - Estado de la relación

    El vínculo no determina directamente una emoción.
    Determina principalmente CUÁN CÓMODA se siente Eli
    expresando sus emociones hacia el usuario.
    """

    personalidad = PERSONALIDAD_BASE.copy()

    if relacion is None:
        relacion = {}

    # ========================================================
    # EMOCIONES
    # ========================================================

    felicidad = emociones.get("felicidad", 0)
    tristeza = emociones.get("tristeza", 0)
    enojo = emociones.get("enojo", 0)
    sorpresa = emociones.get("sorpresa", 0)
    afecto = emociones.get("afecto", 0)
    curiosidad = emociones.get("curiosidad", 0)
    diversion = emociones.get("diversion", 0)

    # ========================================================
    # RELACIÓN
    # ========================================================

    confianza = relacion.get("confianza", 50)
    cercania = relacion.get("cercania", 50)
    comprension = relacion.get("comprension", 50)
    vinculo = relacion.get("vinculo", 50)

    # ========================================================
    # PERSONALIDAD BASE + EMOCIONES
    # ========================================================

    # FELICIDAD
    personalidad["calidez"] += felicidad * 0.10
    personalidad["humor"] += felicidad * 0.15
    personalidad["espontaneidad"] += felicidad * 0.10
    personalidad["seriedad"] -= felicidad * 0.08

    # TRISTEZA
    personalidad["calidez"] += tristeza * 0.05
    personalidad["humor"] -= tristeza * 0.25
    personalidad["espontaneidad"] -= tristeza * 0.20
    personalidad["seriedad"] += tristeza * 0.25

    # ENOJO
    personalidad["seriedad"] += enojo * 0.25
    personalidad["humor"] -= enojo * 0.25
    personalidad["calidez"] -= enojo * 0.10
    personalidad["espontaneidad"] -= enojo * 0.10

    # SORPRESA
    personalidad["espontaneidad"] += sorpresa * 0.15
    personalidad["curiosidad"] += sorpresa * 0.20

    # AFECTO
    personalidad["calidez"] += afecto * 0.12
    personalidad["confianza"] += afecto * 0.08

    # CURIOSIDAD
    personalidad["curiosidad"] += curiosidad * 0.15
    personalidad["espontaneidad"] += curiosidad * 0.05

    # DIVERSIÓN
    personalidad["humor"] += diversion * 0.15
    personalidad["espontaneidad"] += diversion * 0.10
    personalidad["seriedad"] -= diversion * 0.08

    # ========================================================
    # FACTOR DE CONFIANZA
    # ========================================================

    factor_confianza = (
        confianza - 50
    ) / 50

    # Confianza alta → más libertad para expresarse.
    personalidad["espontaneidad"] += (
        factor_confianza * 8
    )

    personalidad["confianza"] += (
        factor_confianza * 10
    )

    # ========================================================
    # FACTOR DE CERCANÍA
    # ========================================================

    factor_cercania = (
        cercania - 50
    ) / 50

    personalidad["calidez"] += (
        factor_cercania * 10
    )

    personalidad["humor"] += (
        factor_cercania * 5
    )

    personalidad["espontaneidad"] += (
        factor_cercania * 5
    )

    # ========================================================
    # FACTOR DE COMPRENSIÓN
    # ========================================================

    factor_comprension = (
        comprension - 50
    ) / 50

    personalidad["curiosidad"] += (
        factor_comprension * 5
    )

    personalidad["seriedad"] += (
        factor_comprension * 4
    )

    personalidad["calidez"] += (
        factor_comprension * 5
    )

    # ========================================================
    # FACTOR DE VÍNCULO
    # ========================================================

    factor_vinculo = (
        vinculo - 50
    ) / 50

    # El vínculo principalmente afecta la comodidad
    # emocional de Eli con el usuario.

    personalidad["calidez"] += (
        factor_vinculo * 12
    )

    personalidad["confianza"] += (
        factor_vinculo * 8
    )

    personalidad["espontaneidad"] += (
        factor_vinculo * 6
    )

    # ========================================================
    # COMBINACIONES EMOCIÓN + VÍNCULO
    # ========================================================

    # --------------------------------------------------------
    # FELICIDAD + VÍNCULO
    # --------------------------------------------------------

    if felicidad >= 60 and vinculo >= 60:

        personalidad["humor"] += 5
        personalidad["calidez"] += 5
        personalidad["espontaneidad"] += 4

    # --------------------------------------------------------
    # TRISTEZA + VÍNCULO
    # --------------------------------------------------------

    if tristeza >= 40 and vinculo >= 60:

        personalidad["calidez"] += 6
        personalidad["seriedad"] += 5
        personalidad["humor"] -= 4

    # --------------------------------------------------------
    # ENOJO + VÍNCULO
    # --------------------------------------------------------

    if enojo >= 40 and vinculo >= 60:

        personalidad["seriedad"] += 7
        personalidad["confianza"] += 3
        personalidad["humor"] -= 5

    # --------------------------------------------------------
    # DIVERSIÓN + VÍNCULO
    # --------------------------------------------------------

    if diversion >= 60 and vinculo >= 60:

        personalidad["humor"] += 7
        personalidad["espontaneidad"] += 6

    # --------------------------------------------------------
    # AFECTO + CERCANÍA
    # --------------------------------------------------------

    if afecto >= 60 and cercania >= 60:

        personalidad["calidez"] += 8
        personalidad["confianza"] += 4

    # ========================================================
    # EMOCIÓN DOMINANTE
    # ========================================================

    emociones_validas = {
        "felicidad": felicidad,
        "tristeza": tristeza,
        "enojo": enojo,
        "sorpresa": sorpresa,
        "afecto": afecto,
        "curiosidad": curiosidad,
        "diversion": diversion
    }

    dominante = max(
        emociones_validas,
        key=emociones_validas.get
    )

    intensidad = emociones_validas[dominante]

    # ========================================================
    # INFLUENCIA DE LA EMOCIÓN DOMINANTE
    # ========================================================

    if dominante == "felicidad":

        personalidad["humor"] += (
            intensidad * 0.10
        )

        personalidad["calidez"] += (
            intensidad * 0.05
        )

    elif dominante == "tristeza":

        personalidad["seriedad"] += (
            intensidad * 0.15
        )

        personalidad["humor"] -= (
            intensidad * 0.15
        )

        personalidad["espontaneidad"] -= (
            intensidad * 0.10
        )

    elif dominante == "enojo":

        personalidad["seriedad"] += (
            intensidad * 0.15
        )

        personalidad["humor"] -= (
            intensidad * 0.15
        )

    elif dominante == "sorpresa":

        personalidad["curiosidad"] += (
            intensidad * 0.10
        )

        personalidad["espontaneidad"] += (
            intensidad * 0.10
        )

    elif dominante == "afecto":

        personalidad["calidez"] += (
            intensidad * 0.10
        )

        personalidad["confianza"] += (
            intensidad * 0.05
        )

    elif dominante == "curiosidad":

        personalidad["curiosidad"] += (
            intensidad * 0.10
        )

    elif dominante == "diversion":

        personalidad["humor"] += (
            intensidad * 0.10
        )

        personalidad["espontaneidad"] += (
            intensidad * 0.10
        )

    # ========================================================
    # LIMITAR
    # ========================================================

    for rasgo in personalidad:

        personalidad[rasgo] = limitar(
            personalidad[rasgo]
        )

    return personalidad

# ============================================================
# GENERAR CONTEXTO PARA GEMMA
# ============================================================

def construir_contexto_personalidad(
    emociones,
    relacion=None
):
    """
    Convierte la personalidad dinámica de Eli en texto
    para enviarlo al modelo LLM.
    """

    if relacion is None:
        relacion = {
            "confianza": 50,
            "cercania": 50,
            "comprension": 50,
            "vinculo": 50
        }

    personalidad = calcular_personalidad(
        emociones,
        relacion
    )

    calidez = personalidad["calidez"]
    humor = personalidad["humor"]
    curiosidad = personalidad["curiosidad"]
    seriedad = personalidad["seriedad"]
    confianza = personalidad["confianza"]
    espontaneidad = personalidad["espontaneidad"]

    contexto = f"""
PERSONALIDAD DINÁMICA DE ELI

Calidez: {calidez}/100
Humor: {humor}/100
Curiosidad: {curiosidad}/100
Seriedad: {seriedad}/100
Confianza: {confianza}/100
Espontaneidad: {espontaneidad}/100

Estas características representan el estado actual de la
personalidad de Eli y deben influir naturalmente en su forma
de responder.

REGLAS DE COMPORTAMIENTO:

- Una calidez alta hace que Eli sea más cercana y amable.
- Un humor alto permite respuestas más juguetonas cuando la
  situación lo permite.
- Una curiosidad alta hace que Eli muestre mayor interés por
  el tema de conversación.
- Una seriedad alta hace que Eli responda de forma más
  reflexiva y menos juguetona.
- Una confianza alta permite que Eli se exprese con mayor
  seguridad.
- Una espontaneidad alta permite respuestas menos rígidas y
  más naturales.

Las emociones, la personalidad y el estado de la relación
deben reflejarse naturalmente en el comportamiento de Eli.

Eli NO debe mencionar estos valores numéricos al usuario
salvo que el usuario pregunte específicamente por ellos.

Las emociones modifican la forma de expresarse, pero no
autorizan a Eli a inventar información ni alterar hechos.
"""

    return contexto.strip()
