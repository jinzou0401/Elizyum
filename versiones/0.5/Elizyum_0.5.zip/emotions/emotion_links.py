# ============================================================
# RELACIONES ENTRE EMOCIONES (contagio/inhibición interna)
#
# OJO: esto es distinto de emotions/relationships.py, que
# maneja la relación de Eli CON EL USUARIO (confianza,
# cercanía, vínculo). Este archivo es sobre cómo las
# emociones de Eli se influyen ENTRE SÍ.
# ============================================================

def aplicar_relaciones_emocionales(emociones):

    resultado = emociones.copy()

    felicidad = emociones.get("felicidad", 0)
    tristeza = emociones.get("tristeza", 0)
    enojo = emociones.get("enojo", 0)
    sorpresa = emociones.get("sorpresa", 0)
    afecto = emociones.get("afecto", 0)
    curiosidad = emociones.get("curiosidad", 0)
    diversion = emociones.get("diversion", 0)

    # --------------------------------------------------------
    # FELICIDAD ALTA
    # --------------------------------------------------------

    if felicidad > 60:
        resultado["diversion"] = min(100, resultado["diversion"] + 3)
        resultado["afecto"] = min(100, resultado["afecto"] + 2)
        resultado["tristeza"] = max(0, resultado["tristeza"] - 3)
        resultado["enojo"] = max(0, resultado["enojo"] - 3)

    # --------------------------------------------------------
    # TRISTEZA ALTA
    # --------------------------------------------------------

    if tristeza > 60:
        resultado["diversion"] = max(0, resultado["diversion"] - 3)
        resultado["afecto"] = min(100, resultado["afecto"] + 2)
        resultado["enojo"] = max(0, resultado["enojo"] - 2)

    # --------------------------------------------------------
    # ENOJO ALTO
    # --------------------------------------------------------

    if enojo > 60:
        resultado["diversion"] = max(0, resultado["diversion"] - 3)
        resultado["afecto"] = max(0, resultado["afecto"] - 2)
        resultado["curiosidad"] = max(0, resultado["curiosidad"] - 2)

    # --------------------------------------------------------
    # AFECTO ALTO
    # --------------------------------------------------------

    if afecto > 60:
        resultado["felicidad"] = min(100, resultado["felicidad"] + 2)
        resultado["diversion"] = min(100, resultado["diversion"] + 2)
        resultado["enojo"] = max(0, resultado["enojo"] - 2)

    # --------------------------------------------------------
    # SORPRESA ALTA
    # --------------------------------------------------------

    if sorpresa > 60:
        resultado["curiosidad"] = min(100, resultado["curiosidad"] + 3)
        resultado["felicidad"] = min(100, resultado["felicidad"] + 1)

    # --------------------------------------------------------
    # CURIOSIDAD ALTA
    # --------------------------------------------------------

    if curiosidad > 60:
        resultado["felicidad"] = min(100, resultado["felicidad"] + 1)

    # --------------------------------------------------------
    # DIVERSIÓN ALTA
    # --------------------------------------------------------

    if diversion > 60:
        resultado["felicidad"] = min(100, resultado["felicidad"] + 2)
        resultado["afecto"] = min(100, resultado["afecto"] + 1)

    return resultado