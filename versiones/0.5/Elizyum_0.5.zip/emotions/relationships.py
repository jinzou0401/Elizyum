# ============================================================
# ELIZYUM - RELATIONSHIPS v3.6
# ============================================================
#
# Sistema persistente de relación entre Eli y Jinzou.
#
# RESPONSABILIDAD:
#
#   - Mantener confianza
#   - Mantener cercanía
#   - Mantener comprensión
#   - Mantener vínculo
#   - Aplicar eventos relacionales
#   - Guardar/cargar relación
#
# NO decide la personalidad de Eli.
#
# relationship_mood.py utiliza posteriormente estos valores
# junto con emociones y eventos recientes para determinar
# la forma de comportamiento de Eli.
#
# ============================================================

import json
import os


# ============================================================
# CONFIGURACIÓN
# ============================================================

ARCHIVO_RELACION = os.path.join(
    "data",
    "memory",
    "eli_relationship.json"
)


# ============================================================
# VALORES INICIALES
# ============================================================

RELACION_INICIAL = {
    "confianza": 50,
    "cercania": 50,
    "comprension": 50,
    "vinculo": 50
}


# ============================================================
# UTILIDAD
# ============================================================

def limitar(
    valor,
    minimo=0,
    maximo=100
):

    try:
        valor = int(round(float(valor)))

    except (
        TypeError,
        ValueError
    ):

        valor = minimo

    return max(
        minimo,
        min(
            maximo,
            valor
        )
    )


# ============================================================
# CREAR DIRECTORIO
# ============================================================

def asegurar_directorio():

    directorio = os.path.dirname(
        ARCHIVO_RELACION
    )

    if directorio:

        os.makedirs(
            directorio,
            exist_ok=True
        )


# ============================================================
# CREAR RELACIÓN
# ============================================================

def crear_relacion():

    asegurar_directorio()

    relacion = RELACION_INICIAL.copy()

    guardar_relacion(
        relacion
    )

    return relacion


# ============================================================
# GUARDAR RELACIÓN
# ============================================================

def guardar_relacion(
    relacion
):

    asegurar_directorio()

    relacion_limpia = {

        "confianza":
            limitar(
                relacion.get(
                    "confianza",
                    50
                )
            ),

        "cercania":
            limitar(
                relacion.get(
                    "cercania",
                    50
                )
            ),

        "comprension":
            limitar(
                relacion.get(
                    "comprension",
                    50
                )
            ),

        "vinculo":
            limitar(
                relacion.get(
                    "vinculo",
                    50
                )
            )
    }

    with open(
        ARCHIVO_RELACION,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            relacion_limpia,
            archivo,
            ensure_ascii=False,
            indent=4
        )


# ============================================================
# CARGAR RELACIÓN
# ============================================================

def cargar_relacion():

    asegurar_directorio()

    if not os.path.exists(
        ARCHIVO_RELACION
    ):

        return crear_relacion()

    try:

        with open(
            ARCHIVO_RELACION,
            "r",
            encoding="utf-8"
        ) as archivo:

            datos = json.load(
                archivo
            )

        return {

            "confianza":
                limitar(
                    datos.get(
                        "confianza",
                        50
                    )
                ),

            "cercania":
                limitar(
                    datos.get(
                        "cercania",
                        50
                    )
                ),

            "comprension":
                limitar(
                    datos.get(
                        "comprension",
                        50
                    )
                ),

            "vinculo":
                limitar(
                    datos.get(
                        "vinculo",
                        50
                    )
                )
        }

    except (
        json.JSONDecodeError,
        OSError
    ):

        return crear_relacion()


# ============================================================
# MODIFICAR RELACIÓN
# ============================================================

def modificar_relacion(
    relacion,
    confianza=0,
    cercania=0,
    comprension=0,
    vinculo=0
):

    relacion["confianza"] = limitar(
        relacion.get(
            "confianza",
            50
        ) + confianza
    )

    relacion["cercania"] = limitar(
        relacion.get(
            "cercania",
            50
        ) + cercania
    )

    relacion["comprension"] = limitar(
        relacion.get(
            "comprension",
            50
        ) + comprension
    )

    relacion["vinculo"] = limitar(
        relacion.get(
            "vinculo",
            50
        ) + vinculo
    )

    return relacion


# ============================================================
# APLICAR EVENTO RELACIONAL
# ============================================================

def aplicar_evento_relacional(
    relacion,
    evento,
    intensidad=0
):

    intensidad = limitar(
        intensidad
    )

    if not evento:

        return relacion


    evento = str(
        evento
    ).lower().strip()


    # ========================================================
    # RECONCILIACIÓN
    # ========================================================

    if evento in (
        "reconciliacion",
        "reconciliación",
        "perdon",
        "perdón",
        "se_reconcilio",
        "se_reconcilió"
    ):

        modificar_relacion(

            relacion,

            confianza=round(
                intensidad * 0.08
            ),

            cercania=round(
                intensidad * 0.08
            ),

            comprension=round(
                intensidad * 0.10
            ),

            vinculo=round(
                intensidad * 0.06
            )
        )


    # ========================================================
    # APOYO
    # ========================================================

    elif evento == "apoyo":

        modificar_relacion(

            relacion,

            confianza=round(
                intensidad * 0.08
            ),

            cercania=round(
                intensidad * 0.08
            ),

            comprension=round(
                intensidad * 0.05
            ),

            vinculo=round(
                intensidad * 0.08
            )
        )


    # ========================================================
    # GESTO CARIÑOSO
    # ========================================================

    elif evento in (
        "gesto_carinoso",
        "gesto_cariñoso"
    ):

        modificar_relacion(

            relacion,

            confianza=round(
                intensidad * 0.03
            ),

            cercania=round(
                intensidad * 0.10
            ),

            comprension=round(
                intensidad * 0.03
            ),

            vinculo=round(
                intensidad * 0.08
            )
        )


    # ========================================================
    # PROMESA CUMPLIDA
    # ========================================================

    elif evento in (
        "cumplio_promesa",
        "cumplió_promesa"
    ):

        modificar_relacion(

            relacion,

            confianza=round(
                intensidad * 0.12
            ),

            cercania=round(
                intensidad * 0.03
            ),

            comprension=round(
                intensidad * 0.04
            ),

            vinculo=round(
                intensidad * 0.06
            )
        )


    # ========================================================
    # PROMESA ROTA
    # ========================================================

    elif evento == "romper_promesa":

        modificar_relacion(

            relacion,

            confianza=-round(
                intensidad * 0.12
            ),

            cercania=-round(
                intensidad * 0.04
            ),

            comprension=-round(
                intensidad * 0.06
            ),

            vinculo=-round(
                intensidad * 0.03
            )
        )


    # ========================================================
    # MENTIRA
    # ========================================================

    elif evento == "mentira":

        modificar_relacion(

            relacion,

            confianza=-round(
                intensidad * 0.18
            ),

            cercania=-round(
                intensidad * 0.05
            ),

            comprension=-round(
                intensidad * 0.08
            ),

            vinculo=-round(
                intensidad * 0.03
            )
        )


    # ========================================================
    # IGNORAR
    # ========================================================

    elif evento == "ignorar":

        modificar_relacion(

            relacion,

            confianza=-round(
                intensidad * 0.02
            ),

            cercania=-round(
                intensidad * 0.10
            ),

            comprension=-round(
                intensidad * 0.04
            ),

            vinculo=-round(
                intensidad * 0.05
            )
        )


    # ========================================================
    # DISCUSIÓN
    # ========================================================

    elif evento in (
        "discusion",
        "discusión"
    ):

        modificar_relacion(

            relacion,

            confianza=-round(
                intensidad * 0.03
            ),

            cercania=-round(
                intensidad * 0.06
            ),

            comprension=-round(
                intensidad * 0.06
            ),

            vinculo=-round(
                intensidad * 0.02
            )
        )


    # ========================================================
    # TRAICIÓN / ENGAÑO
    # ========================================================

    elif evento in (
        "traicion",
        "traición",
        "engaño"
    ):

        modificar_relacion(

            relacion,

            confianza=-round(
                intensidad * 0.20
            ),

            cercania=-round(
                intensidad * 0.08
            ),

            comprension=-round(
                intensidad * 0.10
            ),

            vinculo=-round(
                intensidad * 0.05
            )
        )


    return relacion


# ============================================================
# EXTRAER EVENTO
# ============================================================

def extraer_evento_relacional(
    contexto
):

    if not isinstance(
        contexto,
        dict
    ):

        return (
            None,
            0
        )

    evento = contexto.get(
        "evento_relacional"
    )

    intensidad = contexto.get(
        "intensidad_evento",
        0
    )


    # --------------------------------------------------------
    # FORMATO:
    #
    # {
    #     "evento_relacional": {
    #         "evento": "mentira",
    #         "intensidad": 80
    #     }
    # }
    # --------------------------------------------------------

    if isinstance(
        evento,
        dict
    ):

        nombre_evento = evento.get(
            "evento"
        )

        intensidad = evento.get(
            "intensidad",
            evento.get(
                "intensidad_evento",
                intensidad
            )
        )

        return (
            nombre_evento,
            limitar(
                intensidad
            )
        )


    # --------------------------------------------------------
    # FORMATO:
    #
    # "mentira"
    # --------------------------------------------------------

    if isinstance(
        evento,
        str
    ):

        return (
            evento,
            limitar(
                intensidad
            )
        )


    # --------------------------------------------------------
    # COMPATIBILIDAD:
    #
    # {
    #     "evento": "mentira"
    # }
    # --------------------------------------------------------

    evento_directo = contexto.get(
        "evento"
    )

    if isinstance(
        evento_directo,
        dict
    ):

        return (
            evento_directo.get(
                "evento"
            ),
            limitar(
                evento_directo.get(
                    "intensidad",
                    intensidad
                )
            )
        )


    if isinstance(
        evento_directo,
        str
    ):

        return (
            evento_directo,
            limitar(
                intensidad
            )
        )


    return (
        None,
        0
    )


# ============================================================
# PROCESAR CONTEXTO RELACIONAL
# ============================================================

def procesar_contexto_relacional(
    contexto
):

    relacion = cargar_relacion()

    evento, intensidad = (
        extraer_evento_relacional(
            contexto
        )
    )

    if evento:

        relacion = aplicar_evento_relacional(

            relacion,

            evento,

            intensidad
        )

        guardar_relacion(
            relacion
        )

    return relacion


# ============================================================
# NIVEL GENERAL DEL VÍNCULO
# ============================================================

def obtener_nivel_vinculo(
    relacion=None
):

    if relacion is None:

        relacion = cargar_relacion()

    promedio = (

        relacion.get(
            "confianza",
            50
        )

        +

        relacion.get(
            "cercania",
            50
        )

        +

        relacion.get(
            "comprension",
            50
        )

        +

        relacion.get(
            "vinculo",
            50
        )

    ) / 4

    return limitar(
        promedio
    )


# ============================================================
# DESCRIPCIÓN DEL ESTADO
# ============================================================

def describir_relacion(
    relacion=None
):

    if relacion is None:

        relacion = cargar_relacion()

    nivel = obtener_nivel_vinculo(
        relacion
    )

    if nivel >= 80:

        return "vinculo_muy_alto"

    if nivel >= 65:

        return "vinculo_alto"

    if nivel >= 45:

        return "vinculo_moderado"

    if nivel >= 30:

        return "vinculo_bajo"

    return "vinculo_muy_bajo"


# ============================================================
# DEBUG
# ============================================================

def imprimir_relacion():

    relacion = cargar_relacion()

    print()
    print("=" * 60)
    print("           RELACIÓN ELI - JINZOU")
    print("=" * 60)

    print()

    print(
        f"Confianza:     {relacion['confianza']}/100"
    )

    print(
        f"Cercanía:      {relacion['cercania']}/100"
    )

    print(
        f"Comprensión:   {relacion['comprension']}/100"
    )

    print(
        f"Vínculo:       {relacion['vinculo']}/100"
    )

    print()

    print(
        f"Nivel general: "
        f"{obtener_nivel_vinculo(relacion)}/100"
    )

    print(
        f"Estado:        "
        f"{describir_relacion(relacion)}"
    )

    print()
    print("=" * 60)


# ============================================================
# TEST DIRECTO
# ============================================================

if __name__ == "__main__":

    relacion = cargar_relacion()

    print()
    print("=" * 60)
    print("        TEST RELATIONSHIPS v3.6")
    print("=" * 60)

    print()
    print("RELACIÓN ACTUAL:")
    print(relacion)

    eventos_prueba = [

        ("gesto_carinoso", 60),

        ("apoyo", 60),

        ("cumplio_promesa", 70),

        ("discusion", 50),

        ("romper_promesa", 70),

        ("mentira", 80),

        ("reconciliacion", 60)

    ]

    for evento, intensidad in eventos_prueba:

        print()
        print("-" * 60)

        print(
            f"EVENTO: {evento}"
        )

        print(
            f"INTENSIDAD: {intensidad}"
        )

        relacion = aplicar_evento_relacional(

            relacion,

            evento,

            intensidad
        )

        print()
        print("RELACIÓN:")

        print(
            relacion
        )

    print()
    print("=" * 60)
    print("        FIN TEST RELATIONSHIPS v3.6")
    print("=" * 60)