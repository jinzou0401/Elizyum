import json


# ============================================================
# EVALUADOR DE CONTEXTO
# ============================================================

def analizar_contexto(
    mensaje,
    historial=None
):

    if historial is None:
        historial = []

    contexto = {
        "situacion": "neutral",
        "tono": "neutral",
        "intencion": "conversacion",
        "emociones": {
            "felicidad": 0,
            "tristeza": 0,
            "enojo": 0,
            "sorpresa": 0,
            "afecto": 0,
            "curiosidad": 0,
            "diversion": 0
        }
    }

    texto = mensaje.lower()

    # --------------------------------------------------------
    # CONTEXTO POSITIVO
    # --------------------------------------------------------

    palabras_positivas = [
        "jajaja",
        "jaja",
        "genial",
        "gracias",
        "excelente",
        "increíble",
        "increible",
        "me gusta",
        "feliz"
    ]

    if any(
        palabra in texto
        for palabra in palabras_positivas
    ):

        contexto["situacion"] = "positiva"
        contexto["tono"] = "alegre"

        contexto["emociones"]["felicidad"] = 5
        contexto["emociones"]["afecto"] = 2

    # --------------------------------------------------------
    # DIVERSIÓN
    # --------------------------------------------------------

    if any(
        palabra in texto
        for palabra in [
            "jajaja",
            "jaja",
            "😂",
            "🤣",
            "broma",
            "gracioso"
        ]
    ):

        contexto["emociones"]["diversion"] = 10
        contexto["emociones"]["felicidad"] += 3

    # --------------------------------------------------------
    # TRISTEZA
    # --------------------------------------------------------

    if any(
        palabra in texto
        for palabra in [
            "triste",
            "llorar",
            "llorando",
            "deprimido",
            "mal día",
            "mal dia",
            "preocupado",
            "preocupada"
        ]
    ):

        contexto["situacion"] = "triste"
        contexto["tono"] = "serio"

        contexto["emociones"]["tristeza"] = 8
        contexto["emociones"]["afecto"] = 5

    # --------------------------------------------------------
    # ENOJO
    # --------------------------------------------------------

    if any(
        palabra in texto
        for palabra in [
            "odio",
            "enojado",
            "enojada",
            "molesto",
            "molesta",
            "furioso",
            "furiosa"
        ]
    ):

        contexto["situacion"] = "conflictiva"
        contexto["tono"] = "tenso"

        contexto["emociones"]["enojo"] = 7

    # --------------------------------------------------------
    # SORPRESA
    # --------------------------------------------------------

    if any(
        palabra in texto
        for palabra in [
            "¿qué?",
            "que?",
            "wow",
            "wow!",
            "enserio",
            "¿en serio?",
            "increíble"
        ]
    ):

        contexto["emociones"]["sorpresa"] = 8
        contexto["emociones"]["curiosidad"] = 5

    # --------------------------------------------------------
    # CURIOSIDAD
    # --------------------------------------------------------

    if "?" in mensaje:

        contexto["emociones"]["curiosidad"] += 4

    return contexto
