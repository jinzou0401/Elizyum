import json
from pathlib import Path
from datetime import datetime


# ============================================================
# CARPETA DE CONVERSACIONES
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
CONVERSATIONS_DIR = BASE_DIR / "data" / "conversations"

CONVERSATIONS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# OBTENER NOMBRE DE LA CONVERSACIÓN
# ============================================================

def nombre_archivo():

    fecha = datetime.now().strftime(
        "%Y-%m-%d_%H-%M-%S"
    )

    return CONVERSATIONS_DIR / f"{fecha}.json"


# ============================================================
# GUARDAR CONVERSACIÓN
# ============================================================

def guardar_conversacion(messages, archivo):

    datos = {
        "fecha": datetime.now().isoformat(),
        "messages": messages
    }

    with open(
        archivo,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            datos,
            f,
            ensure_ascii=False,
            indent=4
        )


# ============================================================
# CARGAR CONVERSACIÓN
# ============================================================

def cargar_conversacion(archivo):

    if not archivo.exists():
        return None

    try:

        with open(
            archivo,
            "r",
            encoding="utf-8"
        ) as f:

            datos = json.load(f)

        return datos.get(
            "messages",
            []
        )

    except Exception:

        return None


# ============================================================
# OBTENER ÚLTIMA CONVERSACIÓN
# ============================================================

def ultima_conversacion():

    archivos = list(
        CONVERSATIONS_DIR.glob("*.json")
    )

    if not archivos:
        return None

    archivos.sort(
        key=lambda archivo: archivo.stat().st_mtime,
        reverse=True
    )

    return archivos[0]

