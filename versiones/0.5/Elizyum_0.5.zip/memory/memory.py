import json
from pathlib import Path


# ============================================================
# UBICACIÓN DE LA MEMORIA
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

MEMORY_FILE = BASE_DIR / "data" / "memory" / "eli_memory.json"


# ============================================================
# CARGAR MEMORIA
# ============================================================

def cargar_memoria():

    if not MEMORY_FILE.exists():

        return {
            "usuario": {
                "nombre": ""
            },
            "preferencias": {},
            "informacion_importante": []
        }

    try:

        with open(
            MEMORY_FILE,
            "r",
            encoding="utf-8"
        ) as archivo:

            return json.load(archivo)

    except Exception:

        return {
            "usuario": {
                "nombre": ""
            },
            "preferencias": {},
            "informacion_importante": []
        }


# ============================================================
# GUARDAR MEMORIA
# ============================================================

def guardar_memoria(memoria):

    MEMORY_FILE.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(
        MEMORY_FILE,
        "w",
        encoding="utf-8"
    ) as archivo:

        json.dump(
            memoria,
            archivo,
            ensure_ascii=False,
            indent=4
        )

# ============================================================
# ACTUALIZAR UN DATO DE MEMORIA
# ============================================================

def actualizar_memoria(categoria, clave, valor):

    memoria = cargar_memoria()

    if categoria not in memoria:
        memoria[categoria] = {}

    memoria[categoria][clave] = valor

    guardar_memoria(memoria)

    return memoria


# ============================================================
# AGREGAR INFORMACIÓN IMPORTANTE
# ============================================================

def agregar_informacion_importante(informacion):

    memoria = cargar_memoria()

    if "informacion_importante" not in memoria:
        memoria["informacion_importante"] = []

    if informacion not in memoria["informacion_importante"]:

        memoria["informacion_importante"].append(
            informacion
        )

    guardar_memoria(memoria)

    return memoria

def eliminar_informacion_importante(informacion):

    memoria = cargar_memoria()

    lista = memoria.get(
        "informacion_importante",
        []
    )

    informacion = informacion.strip().lower()

    memoria["informacion_importante"] = [
        dato
        for dato in lista
        if informacion not in dato.strip().lower()
    ]

    guardar_memoria(memoria)

    return memoria