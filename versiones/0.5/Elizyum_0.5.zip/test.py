# ============================================================
# ELIZYUM - TEST DE FACETAS Y RELACIÓN
# ============================================================
#
# Prueba el flujo: mensaje -> contexto -> evento relacional
# -> relación -> estado relacional -> faceta
#
# NO llama a Gemma y NO toca los archivos guardados de la
# app real (data/memory/eli_relationship.json,
# eli_emotions.json). Usa una relación simulada en memoria
# que se descarta al terminar el test.
# ============================================================

from context_ai import analizar_contexto

from emotions.relationships import (
    extraer_evento_relacional,
    aplicar_evento_relacional,
    RELACION_INICIAL
)

from emotions.relationship_mood import (
    determinar_estado_relacional,
    obtener_estado_faceta,
    construir_contexto_faceta
)


# ============================================================
# FUNCIÓN PRINCIPAL DEL TEST
# ============================================================

def ejecutar_test(mensaje, relacion):

    print()
    print("=" * 70)
    print("MENSAJE")
    print("=" * 70)
    print(mensaje)

    # --------------------------------------------------------
    # 1. CONTEXTO
    # --------------------------------------------------------

    contexto = analizar_contexto(mensaje)

    # --------------------------------------------------------
    # NORMALIZAR AMENAZA (context_ai.py la anida bajo
    # "contexto_relacional", pero relationship_mood.py la
    # busca sin anidar)
    # --------------------------------------------------------

    info_amenaza = contexto.get("contexto_relacional", {})

    if isinstance(info_amenaza, dict):
        contexto["amenaza_relacional"] = info_amenaza.get(
            "amenaza_relacional", False
        )
        contexto["intensidad_amenaza"] = info_amenaza.get(
            "intensidad", 0
        )

    # --------------------------------------------------------
    # NORMALIZAR "distante" -> "distancia"
    # --------------------------------------------------------

    if contexto.get("situacion") == "distante":
        contexto["situacion"] = "distancia"

    if contexto.get("estado_relacional") == "distante":
        contexto["estado_relacional"] = "distancia"

    print()
    print("-" * 70)
    print("CONTEXTO DETECTADO (normalizado)")
    print("-" * 70)
    print(contexto)

    # --------------------------------------------------------
    # 2. EVENTO RELACIONAL -> RELACIÓN (simulada)
    # --------------------------------------------------------

    evento, intensidad = extraer_evento_relacional(contexto)

    if evento:
        relacion = aplicar_evento_relacional(
            relacion,
            evento,
            intensidad
        )

    print()
    print("-" * 70)
    print("RELACIÓN SIMULADA (no se guarda en disco)")
    print("-" * 70)
    print(relacion)

    # --------------------------------------------------------
    # 3. ESTADO RELACIONAL
    # --------------------------------------------------------

    estado_relacional = determinar_estado_relacional(
        contexto=contexto,
        relacion=relacion
    )

    print()
    print("-" * 70)
    print("ESTADO RELACIONAL")
    print("-" * 70)
    print(estado_relacional)

    # --------------------------------------------------------
    # 4. FACETA
    # --------------------------------------------------------

    emociones = contexto.get("emociones", {})

    estado_faceta = obtener_estado_faceta(
        emociones=emociones,
        contexto=contexto,
        relacion=relacion,
        estado_relacional=estado_relacional
    )

    print()
    print("-" * 70)
    print("FACETA")
    print("-" * 70)
    print(estado_faceta)

    # --------------------------------------------------------
    # 5. CONTEXTO COMPLETO PARA GEMMA
    # --------------------------------------------------------

    contexto_faceta = construir_contexto_faceta(
        estado_faceta,
        contexto
    )

    print()
    print("-" * 70)
    print("CONTEXTO DE FACETA PARA GEMMA")
    print("-" * 70)
    print(contexto_faceta)

    print()
    print("=" * 70)
    print("TEST COMPLETADO")
    print("=" * 70)

    return relacion


# ============================================================
# CASOS DE PRUEBA
# ============================================================

MENSAJES_PRUEBA = [
    "Hola Eli",                          # normal
    "Jajaja mira esto 😂",                # juguetona
    "Te quiero mucho",                   # cariño
    "Estoy enojado contigo",             # discusión
    "Perdón Eli, no quería hacerlo",     # reconciliación
    "Me gusta otra chica",               # posible celo/amenaza
    "Necesito espacio",                  # distancia
    "Cumplí mi promesa",                 # promesa cumplida
    "Rompí mi promesa",                  # promesa rota
    "Te mentí"                           # mentira
]


# ============================================================
# EJECUCIÓN
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 70)
    print("ELIZYUM - TEST DE FACETAS Y RELACIÓN")
    print("=" * 70)
    print()
    print(f"Se ejecutarán {len(MENSAJES_PRUEBA)} casos de prueba.")
    print("La relación empieza en los valores base (50/50/50/50)")
    print("y se acumula ENTRE los casos, para simular una")
    print("conversación real. No se guarda en disco.")
    print()

    input("Presiona ENTER para comenzar...")

    relacion = RELACION_INICIAL.copy()

    for numero, mensaje in enumerate(MENSAJES_PRUEBA, start=1):

        print()
        print()
        print("#" * 70)
        print(f"PRUEBA {numero}/{len(MENSAJES_PRUEBA)}")
        print("#" * 70)

        relacion = ejecutar_test(mensaje, relacion)

        print()
        input("Presiona ENTER para continuar...")

    print()
    print()
    print("=" * 70)
    print("TEST FINALIZADO")
    print("=" * 70)